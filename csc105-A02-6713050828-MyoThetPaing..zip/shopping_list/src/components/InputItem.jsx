import React, { useState } from 'react';

function InputItem({ addItem }) {
  const [newItem, setNewItem] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault();
    const trimmedItem = newItem.trim();
    if (trimmedItem !== '') {
      console.log('Adding item:', trimmedItem);
      addItem(trimmedItem);
      setNewItem('');
    }
  };

  return (
    <form onSubmit={handleSubmit}>
      <input
        type="text"
        value={newItem}
        onChange={(e) => setNewItem(e.target.value)}
        placeholder="Add a new item"
      />
      <button type="submit">Add</button>
    </form>
  );
}

export default InputItem;
