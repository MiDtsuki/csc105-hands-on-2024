import React, { useState } from 'react';

function ListItem({ item, editItem, removeItem }) {
  const [isCompleted, setIsCompleted] = useState(false);

  const handleItemClick = () => {
    setIsCompleted(!isCompleted);
  };

  return (
    <li
      style={{
        backgroundColor: isCompleted ? '#dff0d8' : '#f2ffe6', // Light green background if completed
        textDecoration: isCompleted ? 'line-through' : 'none', // Strike through if completed
        color: isCompleted ? '#777' : '#333' // Change the color to a lighter gray if completed
      }}
      onClick={handleItemClick}
    >
      {item}
      <div className="button-group">
        <button className="edit-button" onClick={() => editItem(item)}>Edit</button>
        <button className="remove-button" onClick={() => removeItem(item)}>Remove</button>
      </div>
    </li>
  );
}

export default ListItem;
