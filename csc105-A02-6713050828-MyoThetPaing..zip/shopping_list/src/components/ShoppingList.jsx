import React, {useState} from 'react';
import InputItem from './InputItem';
import ListItem from './ListItem';

function ShoppingList(){
    const [items, setItems] = useState(['mango', 'banana']);

    const addItem = (newItem) => {
        console.log('New items array:', [...items, newItem]);
        setItems([...items, newItem]);
      };

    const editItem = (itemToEdit) => {
        const newValue = prompt ("Enter new value for item", itemToEdit);
        if (newValue){
            const updatedItem = items.map(item => item === itemToEdit ? newValue : item);
            setItems(updatedItem);
        }
    };

    const removeItem = (itemToRemove) => {
        setItems(items.filter((item) => item !== itemToRemove));
    };

    return (
        <div>
            <InputItem addItem={addItem}/>
            <ul>
                {items.map((item, index) => (
                    <ListItem
                        key={index}
                        item={item}
                        editItem={editItem}
                        removeItem={removeItem}
                    />
                ))}
            </ul>
        </div>
    );
}

export default ShoppingList;