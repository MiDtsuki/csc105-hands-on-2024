import React, { useState } from 'react';
import './App.css';

function App() {
  const [result, setResult] = useState(0);
  const [input, setInput] = useState('');

  const handleAdd = () => {
    setResult(result + parseFloat(input));
    setInput('');
  };

  const handleSubtract = () => {
    setResult(result - parseFloat(input));
    setInput('');
  };

  const handleMultiply = () => {
    setResult(result * parseFloat(input));
    setInput('');
  };

  const handleDivide = () => {
    setResult(result / parseFloat(input));
    setInput('');
  };

  const resetInput = () => {
    setInput('');
  };

  const resetResult = () => {
    setResult(0);
  };

  return (
    <div className="calculator">
      <h1>Simple Calculator</h1>
      <div className="result">Result: {result}</div>
      <input
        type="number"
        value={input}
        onChange={(e) => setInput(e.target.value)}
        placeholder="Enter a number"
      />
      <div className="buttons">
        <button onClick={handleAdd}>Add</button>
        <button onClick={handleSubtract}>Subtract</button>
        <button onClick={handleMultiply}>Multiply</button>
        <button onClick={handleDivide}>Divide</button>
        <button onClick={resetInput}>Reset Input</button>
        <button onClick={resetResult}>Reset Result</button>
      </div>
    </div>
  );
}

export default App;