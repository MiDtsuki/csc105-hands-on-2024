import React from 'react'

export const HomePage = () => {
  return (
    <div>HomePage</div>
  )
}

export default HomePage;